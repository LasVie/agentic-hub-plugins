# Confluence 连接器

在授权的 Confluence 空间中搜索、读取和创建页面。

安装包后在 WorkSwarm 打开连接器卡片。首次连接时会下载并校验 Atlassian 官方 TWG CLI 1.4.4。在 WorkSwarm 点连接，通过本机授权页打开 Atlassian，选择包含 Confluence 的站点。若 CLI 要求额外的终端输入，需先在终端用相同配置位置完成授权。

需要 Python 3.9 或以上，Windows 卡片命令使用 Python Launcher 选择 Python 3.12。需要访问 Confluence Cloud。服务免费额度、组织授权策略和可用操作由提供商及账号决定。

聊天中选择该连接器及其技能，明确给出目标 ID、操作和目标内容。按目标对象的 ID 回读写入结果。

[提供商文档](https://developer.atlassian.com/cloud/twg-cli/getting-started/installation/)
