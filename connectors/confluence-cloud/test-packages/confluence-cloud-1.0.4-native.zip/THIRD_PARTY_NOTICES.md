# 第三方品牌标志

`icon.png` 源自 [Atlassian 官方品牌素材](https://atlassian.design/foundations/logos)，原文件为 `confluence/PNG/Confluence_icon.png`。商标归 Atlassian 所有。该图标用于在 WorkSwarm 中识别所连接的 Confluence 服务。连接器由 openJiuwen 团队提供。

[适用品牌使用条款](https://www.atlassian.com/legal/trademark)
