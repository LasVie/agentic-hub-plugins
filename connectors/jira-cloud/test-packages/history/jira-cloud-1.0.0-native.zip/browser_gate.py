"""Give WorkSwarm a local URL before starting a desktop CLI's browser login."""

import secrets
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


def await_user():
    route = "/" + secrets.token_urlsafe(24)
    state = {"started": False}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def do_GET(self):
            if self.headers.get("Host") != f"127.0.0.1:{self.server.server_port}":
                self.send_error(400)
                return
            if self.path == route:
                body = f'<meta charset="utf-8"><title>连接 WorkSwarm</title><a href="{route}/start">在浏览器中授权服务</a>'
            elif self.path == route + "/start":
                body = '<meta charset="utf-8"><title>连接 WorkSwarm</title><p>请在接下来打开的服务页面完成授权，然后返回 WorkSwarm。</p>'
                state["started"] = True
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body.encode("utf-8"))

    with HTTPServer(("127.0.0.1", 0), Handler) as server:
        server.timeout = 1
        print(f"http://127.0.0.1:{server.server_port}{route}", flush=True)
        deadline = time.monotonic() + 165
        while not state["started"] and time.monotonic() < deadline:
            server.handle_request()
    return state["started"]
