"""Run a small set of trusted Atlassian CLI commands with scoped arguments."""

import argparse
import errno
import json
import os
import re
import select
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

from browser_gate import await_user
from vendor_runtime import install

PRODUCT = "jira"
IS_JIRA = PRODUCT == "jira"
BINARY = "acli" if IS_JIRA else "twg"
DATA = Path(os.environ.get("JIUWENSWARM_DATA_DIR") or Path.home() / ".jiuwenswarm")
STATE = DATA / "connector-data" / PRODUCT
DOC = ("https://developer.atlassian.com/cloud/acli/guides/install/"
       if IS_JIRA else "https://developer.atlassian.com/cloud/twg-cli/getting-started/installation/")


class ConnectorError(Exception):
    pass


def binary(*, install_if_missing=False):
    system_paths = [
        str(STATE / "bin"), os.environ.get("PATH", ""),
        str(Path.home() / ".local" / "bin"),
        *(("/opt/homebrew/bin", "/usr/local/bin") if os.name != "nt" else ()),
    ]
    found = shutil.which(BINARY, path=os.pathsep.join(filter(None, system_paths)))
    if not found and install_if_missing:
        install(STATE / "bin")
        return binary()
    if not found:
        raise ConnectorError(f"未找到官方 {BINARY}，请按说明安装后重试。{DOC}")
    return found


def env():
    STATE.mkdir(mode=0o700, parents=True, exist_ok=True)
    scoped = dict(os.environ)
    if IS_JIRA:
        scoped["ACLI_CONFIG_DIR"] = str(STATE / "acli")
        scoped["XDG_CONFIG_HOME"] = str(STATE)
    else:
        scoped["TWG_CONFIG_DIR"] = str(STATE / "twg")
    return scoped


def run(args, *, require=True, timeout=40):
    proc = subprocess.run(
        [binary(), *args], stdin=subprocess.DEVNULL, capture_output=True,
        text=True, encoding="utf-8", errors="replace", env=env(), timeout=timeout,
    )
    if proc.returncode and require:
        raise ConnectorError(f"{BINARY} 操作失败（退出码 {proc.returncode}）。请核对登录、站点、目标和权限。")
    return proc


def browser_auth(args):
    if os.name == "nt":
        return subprocess.run([binary(), *args], env=env(), timeout=180,
                              creationflags=subprocess.CREATE_NEW_CONSOLE).returncode
    import pty

    argv = [binary(), *args]
    environment = env()
    if not IS_JIRA:
        environment.pop("TWG_AGENT_DEFAULTS", None)
    pid, master = pty.fork()
    if pid == 0:
        try:
            os.execve(argv[0], argv, environment)
        finally:
            os._exit(127)
    end = time.monotonic() + 180
    waited = False
    try:
        while time.monotonic() < end:
            ready, _, _ = select.select([master], [], [], 0.25)
            if ready:
                try:
                    os.read(master, 8192)
                except OSError as error:
                    if error.errno != errno.EIO:
                        raise
            child, status = os.waitpid(pid, os.WNOHANG)
            if child:
                waited = True
                return os.waitstatus_to_exitcode(status)
        raise ConnectorError(f"{BINARY} 授权超时。若 CLI 要求终端输入，可按说明在终端完成授权。")
    finally:
        os.close(master)
        if not waited:
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            os.waitpid(pid, 0)


def status():
    argv = ["jira", "auth", "status"] if IS_JIRA else ["doctor", "--basic", "-o", "json"]
    result = run(argv, require=False)
    if IS_JIRA:
        return result.returncode == 0
    if result.returncode != 0:
        return False
    data = json.loads(result.stdout)
    if not isinstance(data, dict):
        return False
    return data.get("data", {}).get("auth", {}).get("resolved", {}).get("tokenPresent") is True


def select_command(args):
    if IS_JIRA:
        prefix = ["jira", "workitem"]
        if args.command == "search":
            return prefix + ["search", "--jql", args.query, "--limit", "25", "--json"]
        if args.command == "read":
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,40}-[1-9][0-9]*", args.id):
                raise ConnectorError("请输入 Jira 工单键，例如 DEMO-123。")
            return prefix + ["view", "--json", args.id]
        return prefix + ["create", "--project", args.container, "--type", args.type,
                         "--summary", args.title, "--description", args.body]
    prefix = ["confluence", "content"]
    if args.command == "search":
        return ["confluence", "search", "query", "--cql", args.query, "--limit", "20", "-o", "json"]
    if args.command == "read":
        if not args.id.isdigit():
            raise ConnectorError("请输入 Confluence 页面的数字 ID。")
        return prefix + ["get", args.id, "-o", "json"]
    return prefix + ["create", "--content-type", "page", "--space-id", args.container,
                     "--title", args.title, "--body", args.body, "--format", "markdown",
                     "--ack-body-formats", "--yes", "-o", "json"]


def main():
    parser = argparse.ArgumentParser(description=f"读取和创建 {PRODUCT} 记录")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("prepare", "version", "status", "login", "logout"):
        commands.add_parser(name)
    query = commands.add_parser("search")
    query.add_argument("--query", required=True)
    read = commands.add_parser("read")
    read.add_argument("--id", required=True)
    create = commands.add_parser("create")
    create.add_argument("--container", required=True)
    create.add_argument("--title", required=True)
    create.add_argument("--body", default="")
    if IS_JIRA:
        create.add_argument("--type", default="Task")
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            binary(install_if_missing=True)
            result = {"ready": True}
        elif args.command == "version":
            result = {"version": "1.0.0", "provider_cli": run(["--version"]).stdout.strip()}
        elif args.command == "status":
            try:
                connected = status()
            except (ConnectorError, ValueError):
                connected = False
            result = {"connected": connected}
        elif args.command == "login":
            binary()
            if not await_user():
                raise ConnectorError("等待打开授权入口超时，请重新点击连接。")
            argv = ["jira", "auth", "login", "--web"] if IS_JIRA else ["login"]
            if browser_auth(argv) or not status():
                raise ConnectorError("服务登录未完成，请核对授权及站点权限。")
            result = {"connected": True}
        elif args.command == "logout":
            run(["jira", "auth", "logout"] if IS_JIRA else ["logout"], require=False)
            result = {"connected": status()}
            if result["connected"]:
                raise ConnectorError("官方 CLI 仍显示已登录，请检查账号状态。")
        else:
            output = run(select_command(args)).stdout.strip()
            try:
                result = json.loads(output)
            except ValueError:
                result = {"provider_output": output}
    except (ConnectorError, OSError, ValueError, subprocess.TimeoutExpired) as error:
        print(str(error) if isinstance(error, (ConnectorError, ValueError)) else f"{BINARY} 无法完成操作。", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
