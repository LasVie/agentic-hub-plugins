# monday.com 连接器

查询指定 monday.com 看板条目，读写测试看板中的条目。

安装包后在 WorkSwarm 打开连接器卡片。在 monday.com 账户中创建个人 API 令牌，只在 WorkSwarm 卡片密钥栏填写。先确认用户具有目标看板的编辑权限。命令可使用返回的 cursor 翻页，API 调用计入账户额度。

需要 Python 3.9 或以上，Windows 卡片命令使用 Python Launcher 选择 Python 3.12。需要访问 monday.com。服务免费额度、组织授权策略和可用操作由提供商及账号决定。

聊天中选择该连接器及其技能，明确给出目标 ID、操作和目标内容。按目标对象的 ID 回读写入结果。

[提供商文档](https://developer.monday.com/api-reference/reference/items)
