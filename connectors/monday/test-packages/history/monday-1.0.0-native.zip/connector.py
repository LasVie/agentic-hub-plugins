"""Provider-scoped task operations with fixed destinations and no secret output."""

import argparse
import json
import os
import re
import sys

from http_client import ConnectorError, request



def gid(value):
    if not re.fullmatch(r"[0-9]{1,32}", value):
        raise argparse.ArgumentTypeError("请输入数字 ID。")
    return value


def limit(value):
    number = int(value)
    if not 1 <= number <= 100:
        raise argparse.ArgumentTypeError("返回数量应为 1 至 100。")
    return number


class Monday:
    token_var = "MONDAY_PERSONAL_TOKEN"
    resource = "看板"

    def __init__(self, token):
        self.headers = {"Authorization": token, "API-Version": "2026-07"}

    def call(self, query, variables=None):
        body = request("https://api.monday.com/v2", headers=self.headers, body={
            "query": query,
            "variables": variables or {},
        })
        if not isinstance(body.get("data"), dict) or body.get("errors"):
            raise ConnectorError("monday.com 拒绝了操作，请核对账号权限、看板 ID 和接口额度。")
        return body["data"]

    def status(self):
        return {"connected": bool(self.call("query { me { id } }").get("me", {}).get("id"))}

    def list(self, args):
        if args.cursor:
            return self.call(
                "query ($cursor:String!, $limit:Int!) { next_items_page(cursor:$cursor, limit:$limit) { cursor items { id name url board { id } } } }",
                {"cursor": args.cursor, "limit": args.limit},
            )
        return self.call(
            "query ($board:ID!, $limit:Int!) { boards(ids:[$board]) { id name items_page(limit:$limit) { cursor items { id name url } } } }",
            {"board": args.container, "limit": args.limit},
        )

    def read(self, args):
        return self.call(
            "query ($item:ID!) { items(ids:[$item]) { id name url board { id } column_values { id text } } }",
            {"item": args.item},
        )

    def create(self, args):
        return self.call(
            "mutation ($board:ID!, $name:String!) { create_item(board_id:$board, item_name:$name) { id name url board { id } } }",
            {"board": args.container, "name": args.title},
        )


CLIENT = Monday


def main():
    parser = argparse.ArgumentParser(description=f"查询和创建{CLIENT.resource}任务")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("status", help="检查服务授权")
    listing = commands.add_parser("list", help="列出任务")
    listing.add_argument("--container", required=True, type=gid)
    listing.add_argument("--limit", default=25, type=limit)
    listing.add_argument("--cursor")
    reading = commands.add_parser("read", help="按 ID 读取任务")
    reading.add_argument("--item", required=True, type=gid)
    creation = commands.add_parser("create", help="在指定容器创建任务")
    creation.add_argument("--container", required=True, type=gid)
    creation.add_argument("--title", required=True)
    args = parser.parse_args()
    try:
        token = os.environ.get(CLIENT.token_var, "").strip()
        if not token:
            raise ConnectorError("请先在 WorkSwarm 连接器卡片中填写访问令牌。")
        if args.command == "create" and not args.title.strip():
            raise ConnectorError("任务标题不能为空。")
        result = getattr(CLIENT(token), args.command)(*(() if args.command == "status" else (args,)))
    except (ConnectorError, TypeError, AttributeError) as error:
        msg = str(error) if isinstance(error, ConnectorError) else "服务返回了无法读取的任务数据。"
        print(msg, file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
