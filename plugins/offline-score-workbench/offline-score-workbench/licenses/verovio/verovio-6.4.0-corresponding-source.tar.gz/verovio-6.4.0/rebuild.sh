#!/bin/sh
# 在独立的源码副本中重建浏览器引擎。需要事先配置下列说明中的工具。
set -eu
cd "$(dirname "$0")/emscripten"
emcmake cmake -S ../cmake -B build \
  -DBUILD_AS_WASM=ON -DNO_HUMDRUM_SUPPORT=ON -DNO_EDIT_SUPPORT=OFF \
  -DNO_MXL_SUPPORT=ON -DNO_ABC_SUPPORT=ON -DNO_GABC_SUPPORT=ON -DNO_PAE_SUPPORT=ON \
  -DCMAKE_CXX_FLAGS="-O3 -DNDEBUG -std=c++20 -s STRICT=1 -fwasm-exceptions"
cmake --build build --parallel 8
em++ build/libverovio.a -O3 -DNDEBUG -std=c++20 -s STRICT=1 -fwasm-exceptions \
  -s WASM=1 -s INITIAL_MEMORY=128MB -s MAXIMUM_MEMORY=256MB -s STACK_SIZE=64MB \
  -s ALLOW_MEMORY_GROWTH=1 -s DYNAMIC_EXECUTION=0 -s ENVIRONMENT=web,worker,node \
  -s INCOMING_MODULE_JS_API=onRuntimeInitialized -s SINGLE_FILE=1 \
  --embed-file data/ -s EXPORTED_FUNCTIONS=@exports.txt \
  -s 'EXPORTED_RUNTIME_METHODS=["cwrap","HEAPU8"]' -o build/verovio.js
npm --prefix npm ci --ignore-scripts --no-audit --no-fund
npm --prefix npm run prebundle -- -o "$PWD/build/verovio-toolkit-wasm.js"
