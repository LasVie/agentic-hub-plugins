# 对应源码与构建入口

本目录来自 Mapshaper 0.7.101，提交 b44c0fa95effac3d91526c8b62dc0de0ab88b464。
原始 src 文件、package.json、package-lock.json、rollup.config.mjs 与 LICENSE 保持原样。
仅排除浏览器完整 GUI、独立 GeoPackage/GeoParquet/GeoTIFF 入口、测试数据、字体、图片和文档。
新增 build-runtime.config.mjs 只选择核心与 modules.js 两个构建目标。

开发环境需要 Node.js >=20.11.0 和 npm。进入本目录后可安装锁定的构建依赖并尝试构建：

```sh
npm ci --ignore-scripts
npx --no-install rollup --config build-runtime.config.mjs
```

安装构建依赖需要联网；运行随插件提供的浏览器文件不需要 npm 或联网。
这些命令是首选源码构建入口说明，不代表本插件已进行独立可重复构建验证。
实际交付运行时直接取自已固定的官方 npm 包，未重新编译或修改。
各第三方原始许可见插件根目录 THIRD_PARTY_NOTICES.md 与 licenses/。
本文件和构建选择器由本插件新增，其余对应源文件保留原始声明。
