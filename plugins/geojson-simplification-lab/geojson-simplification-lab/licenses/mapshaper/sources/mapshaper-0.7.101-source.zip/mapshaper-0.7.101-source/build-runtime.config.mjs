// Plugin-owned build selector; upstream modules remain unchanged.
import fs from 'node:fs';
import configs from './rollup.config.mjs';
fs.mkdirSync('www', { recursive: true });
export default configs.filter(config => (Array.isArray(config.output) ? config.output : [config.output]).some(output => ['mapshaper.js', 'www/modules.js'].includes(output.file)));
