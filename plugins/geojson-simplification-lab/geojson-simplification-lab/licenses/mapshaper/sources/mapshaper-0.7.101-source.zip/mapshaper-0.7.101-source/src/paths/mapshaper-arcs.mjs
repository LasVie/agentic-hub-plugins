
import { calcArcBounds, absArcId, countFilteredVertices, filterVertexData } from '../paths/mapshaper-arc-utils';
import { ArcIter, FilteredArcIter, ShapeIter } from '../paths/mapshaper-shape-iter';
import { clampIntervalByPct } from '../paths/mapshaper-path-utils';
import { getThresholdByPct } from '../simplify/mapshaper-simplify-pct';
import { Bounds } from '../geom/mapshaper-bounds';
import { probablyDecimalDegreeBounds } from '../geom/mapshaper-latlon';
import { error } from '../utils/mapshaper-logging';
import utils from '../utils/mapshaper-utils';
import {
  getUndoId,
  getUndoRevision,
  markArcsChanged,
  markArcsSimplificationChanged,
  noteArcsSimplificationWillChange,
  noteArcsWillAppend,
  noteArcsWillChange
} from '../undo/mapshaper-undo-tracking';

// An interface for managing a collection of paths.
// Constructor signatures:
//
// ArcCollection(arcs)
//    arcs is an array of polyline arcs; each arc is an array of points: [[x0, y0], [x1, y1], ... ]
//
// ArcCollection(nn, xx, yy)
//    nn is an array of arc lengths; xx, yy are arrays of concatenated coords;
export function ArcCollection() {
  var _xx, _yy,  // coordinates data
      _ii, _nn,  // indexes, sizes
      _zz, _zlimit = 0, // simplification
      _bb, _allBounds, // bounding boxes
      _arcIter, _filteredArcIter, // path iterators
      // Arrays with spare capacity, allocated by appendArcs(). Only these are
      // written past the end of the current data: arrays received from
      // elsewhere may be views into a buffer that holds other data.
      _capNN = null, _capXX = null, _capYY = null;

  if (arguments.length == 1) {
    initLegacyArcs(arguments[0]);  // want to phase this out
  } else if (arguments.length == 3) {
    initXYData.apply(this, arguments);
  } else if (arguments.length === 0) {
    initLegacyArcs([]); // empty collection
  } else {
    error("ArcCollection() Invalid arguments");
  }

  function initLegacyArcs(arcs) {
    var xx = [], yy = [];
    var nn = arcs.map(function(points) {
      var n = points ? points.length : 0;
      for (var i=0; i<n; i++) {
        xx.push(points[i][0]);
        yy.push(points[i][1]);
      }
      return n;
    });
    initXYData(nn, xx, yy);
  }

  function initXYData(nn, xx, yy) {
    var size = nn.length;
    if (nn instanceof Array) nn = new Uint32Array(nn);
    if (xx instanceof Array) xx = new Float64Array(xx);
    if (yy instanceof Array) yy = new Float64Array(yy);
    _xx = xx;
    _yy = yy;
    _nn = nn;
    _zz = null;
    _zlimit = 0;
    _filteredArcIter = null;

    // generate array of starting idxs of each arc
    _ii = new Uint32Array(size);
    for (var idx = 0, j=0; j<size; j++) {
      _ii[j] = idx;
      idx += nn[j];
    }

    if (idx != _xx.length || _xx.length != _yy.length) {
      error("ArcCollection#initXYData() Counting error");
    }

    initBounds();
    // Pre-allocate some path iterators for repeated use.
    _arcIter = new ArcIter(_xx, _yy);
    return this;
  }

  function initZData(zz) {
    if (!zz) {
      _zz = null;
      _zlimit = 0;
      _filteredArcIter = null;
    } else {
      if (zz.length != _xx.length) error("ArcCollection#initZData() mismatched arrays");
      if (zz instanceof Array) zz = new Float64Array(zz);
      _zz = zz;
      _filteredArcIter = new FilteredArcIter(_xx, _yy, _zz);
    }
  }

  function initBounds() {
    var numArcs = _nn.length;
    _bb = new Float64Array(numArcs * 4);
    _allBounds = new Bounds();
    for (var i=0; i<numArcs; i++) {
      initArcBounds(i);
    }
  }

  function initArcBounds(i) {
    var arcLen = _nn[i];
    var arcOffs = _ii[i];
    var j = i * 4;
    var b = calcArcBounds(_xx, _yy, arcOffs, arcLen);
    // NOTE: if arcLen is 0, bounds coords are undefined, coerced to NaN in _bb.
    _bb[j++] = b[0];
    _bb[j++] = b[1];
    _bb[j++] = b[2];
    _bb[j] = b[3];
    _allBounds.mergeBounds(b);
  }

  this.updateArcBounds = function(arcId) {
    this.captureArcsBefore({operation: 'updateArcBounds', arcId: arcId});
    initArcBounds(arcId);
    this.markArcsChanged({operation: 'updateArcBounds', arcId: arcId});
  };

  this.updateVertexData = function(nn, xx, yy, zz) {
    this.captureArcsBefore({operation: 'updateVertexData'});
    clearAppendCapacity();
    initXYData(nn, xx, yy);
    initZData(zz || null);
    this.markArcsChanged({operation: 'updateVertexData'});
  };

  // Adds arcs to the end of the collection, leaving the ids of existing arcs
  // unchanged. Unlike merging, this copies only the new vertices (most of the
  // time), and undo takes it back by truncating the collection, without a
  // copy of the existing arcs.
  // nn, xx, yy: vertex data of the arcs to add
  this.appendArcs = function(nn, xx, yy) {
    var arcCount = _nn.length + nn.length,
        pointCount = _xx.length + xx.length,
        zlimit = _zlimit;
    if (_zz) {
      error('ArcCollection#appendArcs() Simplified arcs are not supported');
    }
    if (xx.length != yy.length) {
      error('ArcCollection#appendArcs() Mismatched arrays');
    }
    noteArcsWillAppend(this, {operation: 'appendArcs'});
    if (!hasAppendCapacity(arcCount, pointCount)) {
      allocateAppendCapacity(arcCount, pointCount);
    }
    _capNN.set(nn, _nn.length);
    _capXX.set(xx, _xx.length);
    _capYY.set(yy, _yy.length);
    initXYData(_capNN.subarray(0, arcCount), _capXX.subarray(0, pointCount),
      _capYY.subarray(0, pointCount));
    _zlimit = zlimit;
    this.markArcsChanged({operation: 'appendArcs'});
  };

  // Removes arcs from the end of the collection, keeping the first @arcCount
  // (used by undo to take back appendArcs()).
  this.truncateArcs = function(arcCount) {
    var zz = _zz,
        zlimit = _zlimit,
        pointCount;
    if (!(arcCount >= 0 && arcCount <= _nn.length)) {
      error('ArcCollection#truncateArcs() Invalid arc count:', arcCount);
    }
    pointCount = arcCount < _nn.length ? _ii[arcCount] : _xx.length;
    this.captureArcsBefore({operation: 'truncateArcs'});
    initXYData(_nn.subarray(0, arcCount), _xx.subarray(0, pointCount),
      _yy.subarray(0, pointCount));
    initZData(zz ? zz.subarray(0, pointCount) : null);
    _zlimit = zlimit;
    this.markArcsChanged({operation: 'truncateArcs'});
  };

  function hasAppendCapacity(arcCount, pointCount) {
    return !!_capNN &&
      _nn.buffer === _capNN.buffer && _capNN.length >= arcCount &&
      _xx.buffer === _capXX.buffer && _capXX.length >= pointCount &&
      _yy.buffer === _capYY.buffer && _capYY.length >= pointCount;
  }

  // Copies the current data into new arrays, with room for growth, so that
  // a series of appends doesn't copy every vertex each time
  function allocateAppendCapacity(arcCount, pointCount) {
    var nn = new Uint32Array(arcCount + getSpareCapacity(arcCount)),
        xx = new Float64Array(pointCount + getSpareCapacity(pointCount)),
        yy = new Float64Array(xx.length);
    nn.set(_nn);
    xx.set(_xx);
    yy.set(_yy);
    _capNN = nn;
    _capXX = xx;
    _capYY = yy;
  }

  function getSpareCapacity(n) {
    return Math.max(4096, Math.ceil(n * 0.1));
  }

  function clearAppendCapacity() {
    _capNN = _capXX = _capYY = null;
  }

  this.getUndoId = function() {
    return getUndoId(this);
  };

  this.getUndoRevision = function() {
    return getUndoRevision(this);
  };

  this.captureArcsBefore = function(detail) {
    noteArcsWillChange(this, detail);
  };

  this.captureArcsSimplificationBefore = function(detail) {
    noteArcsSimplificationWillChange(this, detail);
  };

  this.markArcsChanged = function(detail) {
    return markArcsChanged(this, detail);
  };

  this.markArcsSimplificationChanged = function(detail) {
    return markArcsSimplificationChanged(this, detail);
  };

  this.getCopy = function() {
    var copy = new ArcCollection(new Int32Array(_nn), new Float64Array(_xx),
        new Float64Array(_yy));
    if (_zz) {
      copy.setThresholds(new Float64Array(_zz));
      copy.setRetainedInterval(_zlimit);
    }
    return copy;
  };


  // Give access to raw data arrays...
  this.getVertexData = getVertexData;

  function getVertexData() {
    return {
      xx: _xx,
      yy: _yy,
      zz: _zz,
      bb: _bb,
      nn: _nn,
      ii: _ii
    };
  }

  function getFilteredPointCount() {
    if (!_zz || !_zlimit) return this.getPointCount();
    return countFilteredVertices(_zz, _zlimit);
  }

  function getFilteredVertexData() {
    return filterVertexData(getVertexData(), _zlimit);
  }

  this.getFilteredCopy = function() {
    if (!_zz || _zlimit === 0) return this.getCopy();
    var data = getFilteredVertexData();
    var copy = new ArcCollection(data.nn, data.xx, data.yy);
    copy.setThresholds(data.zz);
    return copy;
  };

  // Return arcs as arrays of [x, y] points (intended for testing).
  this.toArray = function() {
    var arr = [];
    this.forEach(function(iter) {
      var arc = [];
      while (iter.hasNext()) {
        arc.push([iter.x, iter.y]);
      }
      arr.push(arc);
    });
    return arr;
  };

  this.toJSON = function() {
    return this.toArray();
  };

  // @cb function(i, j, xx, yy)
  this.forEachArcSegment = function(arcId, cb) {
    var fw = arcId >= 0,
        absId = fw ? arcId : ~arcId,
        zlim = this.getRetainedInterval(),
        n = _nn[absId],
        step = fw ? 1 : -1,
        v1 = fw ? _ii[absId] : _ii[absId] + n - 1,
        v2 = v1,
        xx = _xx, yy = _yy, zz = _zz,
        count = 0;

    for (var j = 1; j < n; j++) {
      v2 += step;
      if (zlim === 0 || zz[v2] >= zlim) {
        cb(v1, v2, xx, yy);
        v1 = v2;
        count++;
      }
    }
    return count;
  };

  // @cb function(i, j, xx, yy)
  this.forEachSegment = function(cb) {
    var count = 0;
    for (var i=0, n=this.size(); i<n; i++) {
      count += this.forEachArcSegment(i, cb);
    }
    return count;
  };

  this.transformPoints = function(f) {
    var xx = _xx, yy = _yy, arcId = -1, n = 0, p;
    this.captureArcsBefore({operation: 'transformPoints'});
    for (var i=0, len=xx.length; i<len; i++, n--) {
      while (n === 0) {
        n = _nn[++arcId];
      }
      p = f(xx[i], yy[i], arcId);
      if (p) {
        xx[i] = p[0];
        yy[i] = p[1];
      }
    }
    initBounds();
    this.markArcsChanged({operation: 'transformPoints'});
  };

  // Return an ArcIter object for each path in the dataset
  //
  this.forEach = function(cb) {
    for (var i=0, n=this.size(); i<n; i++) {
      cb(this.getArcIter(i), i);
    }
  };

  // Iterate over arcs with access to low-level data
  //
  this.forEach2 = function(cb) {
    for (var arcId=0, n=this.size(); arcId<n; arcId++) {
      cb(arcId, _ii[arcId], _nn[arcId], _xx, _yy, _zz);
    }
  };

  this.forEach3 = function(cb) {
    var start, end, xx, yy, zz;
    for (var arcId=0, n=this.size(); arcId<n; arcId++) {
      start = _ii[arcId];
      end = start + _nn[arcId];
      xx = _xx.subarray(start, end);
      yy = _yy.subarray(start, end);
      if (_zz) zz = _zz.subarray(start, end);
      cb(xx, yy, zz, arcId);
    }
  };

  // Remove arcs that don't pass a filter test and re-index arcs
  // Return array mapping original arc ids to re-indexed ids. If arr[n] == -1
  // then arc n was removed. arr[n] == m indicates that the arc at n was
  // moved to index m.
  // Return null if no arcs were re-indexed (and no arcs were removed)
  //
  this.filter = function(cb) {
    var test = function(i) {
      return cb(this.getArcIter(i), i);
    }.bind(this);
    return this.deleteArcs(test);
  };

  this.deleteArcs = function(test) {
    var n = this.size(),
        map = new Int32Array(n),
        goodArcs = 0,
        goodPoints = 0;
    for (var i=0; i<n; i++) {
      if (test(i)) {
        map[i] = goodArcs++;
        goodPoints += _nn[i];
      } else {
        map[i] = -1;
      }
    }
    if (goodArcs < n) {
      this.captureArcsBefore({operation: 'deleteArcs'});
      condenseArcs(map);
      this.markArcsChanged({operation: 'deleteArcs'});
    }
    return map;
  };

  function condenseArcs(map) {
    var goodPoints = 0,
        goodArcs = 0,
        copyElements = utils.copyElements,
        zz = _zz, // initXYData() clears simplification data
        zlimit = _zlimit,
        k, arcLen;
    for (var i=0, n=map.length; i<n; i++) {
      k = map[i];
      arcLen = _nn[i];
      if (k > -1) {
        copyElements(_xx, _ii[i], _xx, goodPoints, arcLen);
        copyElements(_yy, _ii[i], _yy, goodPoints, arcLen);
        if (zz) copyElements(zz, _ii[i], zz, goodPoints, arcLen);
        _nn[k] = arcLen;
        goodPoints += arcLen;
        goodArcs++;
      }
    }

    initXYData(_nn.subarray(0, goodArcs), _xx.subarray(0, goodPoints),
        _yy.subarray(0, goodPoints));
    if (zz) {
      initZData(zz.subarray(0, goodPoints));
      _zlimit = zlimit;
    }
  }

  this.dedupCoords = function() {
    var arcId = 0, i = 0, i2 = 0,
        arcCount = this.size(),
        zz = _zz,
        arcLen, arcLen2;
    this.captureArcsBefore({operation: 'dedupCoords'});
    while (arcId < arcCount) {
      arcLen = _nn[arcId];
      arcLen2 = dedupArcCoords(i, i2, arcLen, _xx, _yy, zz);
      _nn[arcId] = arcLen2;
      i += arcLen;
      i2 += arcLen2;
      arcId++;
    }
    if (i > i2) {
      initXYData(_nn, _xx.subarray(0, i2), _yy.subarray(0, i2));
      if (zz) initZData(zz.subarray(0, i2));
    }
    this.markArcsChanged({operation: 'dedupCoords'});
    return i - i2;
  };

  this.getVertex = function(arcId, nth) {
    var i = this.indexOfVertex(arcId, nth);
    return {
      x: _xx[i],
      y: _yy[i]
    };
  };

  this.getVertex2 = function(i) {
    return [_xx[i], _yy[i]];
  };

  // @nth: index of vertex. ~(idx) starts from the opposite endpoint
  this.indexOfVertex = function(arcId, nth) {
    var absId = arcId < 0 ? ~arcId : arcId,
        len = _nn[absId];
    if (nth < 0) nth = len + nth;
    if (absId != arcId) nth = len - nth - 1;
    if (nth < 0 || nth >= len) {
      error("[ArcCollection] out-of-range vertex id");
    }
    return _ii[absId] + nth;
  };

  // Tests if arc endpoints have same x, y coords
  // (arc may still have collapsed);
  this.arcIsClosed = function(arcId) {
    var i = this.indexOfVertex(arcId, 0),
        j = this.indexOfVertex(arcId, -1);
    return i != j && _xx[i] == _xx[j] && _yy[i] == _yy[j];
  };

  // Tests if first and last segments mirror each other
  // A 3-vertex arc with same endpoints tests true
  this.arcIsLollipop = function(arcId) {
    var len = this.getArcLength(arcId),
        i, j;
    if (len <= 2 || !this.arcIsClosed(arcId)) return false;
    i = this.indexOfVertex(arcId, 1);
    j = this.indexOfVertex(arcId, -2);
    return _xx[i] == _xx[j] && _yy[i] == _yy[j];
  };

  // @unfiltered test all of the arc's vertices, not just the ones that are
  //   retained at the current simplification level
  this.arcIsDegenerate = function(arcId, unfiltered) {
    return this.arcHasZeroLength(arcId, unfiltered) || this.arcIsSpike(arcId) ||
      this.arcIsSpike_v1(arcId, unfiltered);
  };

  // only finds two-segment spikes
  this.arcIsSpike_v1 = function(arcId, unfiltered) {
    var iter = unfiltered ? getUnfilteredArcIter(arcId) : this.getArcIter(arcId);
    var x0, y0;
    if (iter.hasNext()) {
      x0 = iter.x;
      y0 = iter.y;
    }
    iter.hasNext(); // ignore second point
    if (iter.hasNext()) {
      if (iter.x == x0 && iter.y == y0 && !iter.hasNext()) {
        // three-vertex arc, first two are the same
        return true;
      }
    }
    return false;
  };

  // identifies n-segment spikes
  this.arcIsSpike = function(arcId) {
    arcId = absArcId(arcId);
    var i = _ii[arcId];
    var j = i + _nn[arcId] - 1;
    while (j > i) {
      if (_xx[i] != _xx[j] || _yy[i] != _yy[j]) {
        return false;
      }
      j--;
      i++;
    }
    return true;
  };


  this.arcHasZeroLength = function(arcId, unfiltered) {
    var iter = unfiltered ? getUnfilteredArcIter(arcId) : this.getArcIter(arcId);
    var i = 0,
        x, y;
    while (iter.hasNext()) {
      if (i > 0) {
        if (x != iter.x || y != iter.y) return false;
      }
      x = iter.x;
      y = iter.y;
      i++;
    }
    return true;
  };

  this.getArcLength = function(arcId) {
    return _nn[absArcId(arcId)];
  };

  this.getArcIter = function(arcId) {
    var fw = arcId >= 0,
        i = fw ? arcId : ~arcId,
        iter = _zz && _zlimit ? _filteredArcIter : _arcIter;
    if (i >= _nn.length) {
      error("#getArcId() out-of-range arc id:", arcId, `(max id: ${_nn.length - 1})`);
    }
    return iter.init(_ii[i], _nn[i], fw, _zlimit);
  };

  function getUnfilteredArcIter(arcId) {
    var fw = arcId >= 0,
        i = fw ? arcId : ~arcId;
    return _arcIter.init(_ii[i], _nn[i], fw);
  }

  this.getShapeIter = function(ids) {
    return new ShapeIter(this).init(ids);
  };

  // Add simplification data to the dataset
  // @thresholds is either a single typed array or an array of arrays of removal thresholds for each arc;
  //
  this.setThresholds = function(thresholds) {
    var n = this.getPointCount(),
        zz = null;
    this.captureArcsSimplificationBefore({operation: 'setThresholds'});
    if (!thresholds) {
      // nop
    } else if (thresholds.length == n) {
      zz = thresholds;
    } else if (thresholds.length == this.size()) {
      zz = flattenThresholds(thresholds, n);
    } else {
      error("Invalid threshold data");
    }
    initZData(zz);
    this.markArcsSimplificationChanged({operation: 'setThresholds'});
    return this;
  };

  function flattenThresholds(arr, n) {
    var zz = new Float64Array(n),
        i = 0;
    arr.forEach(function(arr) {
      for (var j=0, n=arr.length; j<n; i++, j++) {
        zz[i] = arr[j];
      }
    });
    if (i != n) error("Mismatched thresholds");
    return zz;
  }

  // bake in current simplification level, if any
  this.flatten = function() {
    this.captureArcsBefore({operation: 'flatten'});
    if (_zlimit > 0) {
      var data = getFilteredVertexData();
      this.updateVertexData(data.nn, data.xx, data.yy);
      _zlimit = 0;
    } else {
      _zz = null;
    }
    this.markArcsChanged({operation: 'flatten'});
  };

  this.isFlat = function() { return !_zz; };

  this.getRetainedInterval = function() {
    return _zlimit;
  };

  this.setRetainedInterval = function(z) {
    this.captureArcsSimplificationBefore({operation: 'setRetainedInterval'});
    _zlimit = z;
    this.markArcsSimplificationChanged({operation: 'setRetainedInterval'});
    return this;
  };

  this.getRetainedPct = function() {
    return this.getPctByThreshold(_zlimit);
  };

  this.setRetainedPct = function(pct) {
    this.captureArcsSimplificationBefore({operation: 'setRetainedPct'});
    if (pct >= 1) {
      _zlimit = 0;
    } else {
      _zlimit = this.getThresholdByPct(pct);
      _zlimit = clampIntervalByPct(_zlimit, pct);
    }
    this.markArcsSimplificationChanged({operation: 'setRetainedPct'});
    return this;
  };

  // Return array of z-values that can be removed for simplification
  //
  this.getRemovableThresholds = function(nth) {
    if (!_zz) error("[arcs] Missing simplification data.");
    var skip = nth | 1,
        arr = new Float64Array(Math.ceil(_zz.length / skip)),
        z;
    for (var i=0, j=0, n=this.getPointCount(); i<n; i+=skip) {
      z = _zz[i];
      if (z != Infinity) {
        arr[j++] = z;
      }
    }
    return arr.subarray(0, j);
  };

  this.getArcThresholds = function(arcId) {
    if (!(arcId >= 0 && arcId < this.size())) {
      error("[arcs] Invalid arc id:", arcId);
    }
    var start = _ii[arcId],
        end = start + _nn[arcId];
    return _zz.subarray(start, end);
  };

  // nth (optional): sample every nth threshold (use estimate for speed)
  this.getPctByThreshold = function(val, nth) {
    var arr, rank, pct;
    if (val > 0) {
      arr = this.getRemovableThresholds(nth);
      rank = utils.findRankByValue(arr, val);
      pct = arr.length > 0 ? 1 - (rank - 1) / arr.length : 1;
    } else {
      pct = 1;
    }
    return pct;
  };

  // nth (optional): sample every nth threshold (use estimate for speed)
  this.getThresholdByPct = function(pct, nth) {
    return getThresholdByPct(pct, this, nth);
  };

  this.arcIntersectsBBox = function(i, b1) {
    var b2 = _bb,
        j = i * 4;
    // returns false if _bb bounds are NaN
    return b2[j] <= b1[2] && b2[j+2] >= b1[0] && b2[j+3] >= b1[1] && b2[j+1] <= b1[3];
  };

  this.arcIsContained = function(i, b1) {
    var b2 = _bb,
        j = i * 4;
    // returns false if _bb bounds are NaN
    return b2[j] >= b1[0] && b2[j+2] <= b1[2] && b2[j+1] >= b1[1] && b2[j+3] <= b1[3];
  };

  this.arcIsSmaller = function(i, units) {
    var bb = _bb,
        j = i * 4;
    return bb[j+2] - bb[j] < units && bb[j+3] - bb[j+1] < units;
  };

  // TODO: allow datasets in lat-lng coord range to be flagged as planar
  this.isPlanar = function() {
    return !probablyDecimalDegreeBounds(this.getBounds());
  };

  this.size = function() {
    return _ii && _ii.length || 0;
  };

  this.getPointCount = function() {
    return _xx && _xx.length || 0;
  };

  this.getFilteredPointCount = getFilteredPointCount;

  this.getBounds = function() {
    return _allBounds.clone();
  };

  this.getSimpleShapeBounds = function(arcIds, bounds) {
    bounds = bounds || new Bounds();
    for (var i=0, n=arcIds.length; i<n; i++) {
      this.mergeArcBounds(arcIds[i], bounds);
    }
    return bounds;
  };

  this.getSimpleShapeBbox = function(arcIds, arr) {
    var bbox = arr || [],
        bb = _bb,
        arcId, offs;
    bbox[0] = bbox[1] = Infinity;
    bbox[2] = bbox[3] = -Infinity;
    for (var i=0, n=arcIds.length; i<n; i++) {
      arcId = absArcId(arcIds[i]);
      offs = arcId * 4;
      if (bb[offs] < bbox[0]) bbox[0] = bb[offs];
      if (bb[++offs] < bbox[1]) bbox[1] = bb[offs];
      if (bb[++offs] > bbox[2]) bbox[2] = bb[offs];
      if (bb[++offs] > bbox[3]) bbox[3] = bb[offs];
    }
    return bbox[0] == Infinity ? [] : bbox;
  };

  // TODO: move this and similar methods out of ArcCollection
  this.getMultiShapeBounds = function(shp, bounds) {
    bounds = bounds || new Bounds();
    if (shp) { // handle null shapes
      for (var i=0, n=shp.length; i<n; i++) {
        this.getSimpleShapeBounds(shp[i], bounds);
      }
    }
    return bounds;
  };

  this.mergeArcBounds = function(arcId, bounds) {
    if (arcId < 0) arcId = ~arcId;
    var offs = arcId * 4;
    if (_nn[arcId] > 0) {
      bounds.mergeBounds(_bb[offs], _bb[offs+1], _bb[offs+2], _bb[offs+3]);
    }
  };
}

// Remove duplicate coords and NaNs
function dedupArcCoords(src, dest, arcLen, xx, yy, zz) {
  var n = 0, n2 = 0; // counters
  var x, y, i, j, keep;
  while (n < arcLen) {
    j = src + n;
    x = xx[j];
    y = yy[j];
    keep = x == x && y == y && (n2 === 0 || x != xx[j-1] || y != yy[j-1]);
    if (keep) {
      i = dest + n2;
      xx[i] = x;
      yy[i] = y;
      n2++;
    }
    if (zz && n2 > 0 && (keep || zz[j] > zz[i])) {
      zz[i] = zz[j];
    }
    n++;
  }
  return n2 > 1 ? n2 : 0;
}
